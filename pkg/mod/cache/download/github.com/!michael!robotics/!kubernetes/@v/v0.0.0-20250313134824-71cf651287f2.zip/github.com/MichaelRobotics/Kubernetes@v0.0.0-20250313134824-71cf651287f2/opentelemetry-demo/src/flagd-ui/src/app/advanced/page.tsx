// Copyright The OpenTelemetry Authors
// SPDX-License-Identifier: Apache-2.0
import AdvancedView from "@/components/advanced/AdvancedView";

const Advanced = () => {
  return <AdvancedView />;
};

export default Advanced;
