/** @type {import('next').NextConfig} */
const nextConfig = {
  basePath: "/feature",
};

export default nextConfig;
