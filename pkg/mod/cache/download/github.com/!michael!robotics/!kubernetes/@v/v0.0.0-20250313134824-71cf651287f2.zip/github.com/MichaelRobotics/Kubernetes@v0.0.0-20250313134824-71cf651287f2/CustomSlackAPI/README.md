Dir for slack API. In progress.
