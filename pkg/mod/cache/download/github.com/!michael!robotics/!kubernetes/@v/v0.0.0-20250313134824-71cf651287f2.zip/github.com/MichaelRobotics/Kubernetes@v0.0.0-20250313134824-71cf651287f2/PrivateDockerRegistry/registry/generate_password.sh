docker run --entrypoint htpasswd httpd:2 -Bbn myuser mypasswd > auth/htpasswd
