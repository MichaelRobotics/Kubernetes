aws cloudformation delete-stack \
  --region us-east-1 \
  --stack-name my-eks-vpc 