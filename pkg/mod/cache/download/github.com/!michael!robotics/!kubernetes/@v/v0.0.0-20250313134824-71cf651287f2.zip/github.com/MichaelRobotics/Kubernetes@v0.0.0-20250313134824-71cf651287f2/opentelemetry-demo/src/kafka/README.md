# Kafka

This is used as a message queue service to connect the checkout service with
the accounting and fraud detection services.

Kafka is run in KRaft mode. Environment variables are substituted at
deploy-time.
